package com.example.sell.dto;

import lombok.Data;

/**
 * @author zrl
 * @date 2020-12-23 19:40
 */
@Data
public class UserDto {
    //id
    private String id;
    //密码
    private String password;
}
