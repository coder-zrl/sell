package com.example.sell.enums;

/**
 * @author zrl
 * @date 2020-12-18 16:33
 */
public interface CodeEnum {
    Integer getCode();
    String getMsg();
}
